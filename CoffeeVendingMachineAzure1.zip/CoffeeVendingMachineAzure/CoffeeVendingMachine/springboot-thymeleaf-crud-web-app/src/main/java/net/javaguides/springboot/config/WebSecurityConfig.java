package net.javaguides.springboot.config;

import org.springframework.context.annotation.Configuration;
import org.springframework.security.config.annotation.web.builders.HttpSecurity;
import org.springframework.security.config.annotation.web.configuration.WebSecurityConfigurerAdapter;
import org.springframework.security.config.annotation.web.configuration.EnableWebSecurity;

@Configuration
@EnableWebSecurity
public class WebSecurityConfig extends WebSecurityConfigurerAdapter {

    @Override
    protected void configure(HttpSecurity http) throws Exception {
        http
                .csrf().disable()
                .authorizeRequests()
                .antMatchers(
                        "/", "/register", "/forget-password",
                        "/api/users/**", "/api/technicians/**", "/api/machines/**", // ✅ Added
                        "/style.css", "/script.js", "/technician.css", "/technician.js",
                        "/technician-machine", "/technician", "/admin", "/index",
                        "/register.css", "/register.js", "/forget-password.js",
                        "/technician-machine.css", "/technician-machine.js",
                        "/admin.css", "/admin.js","/api/admin/location/**","/admin-machine",
                        "/admin-machine.css","/admin-machine.js","/saveMachine","/api/notifications/**","/technician-home","/technician-home.css"
                        ,"/admin-home","/admin-home.css","/images/**","/slideshow","/slideshow.css","/slideshow.js","/forget-password.css"
                ).permitAll()
                .anyRequest().authenticated()
                .and()
                .formLogin().disable();
    }
}
