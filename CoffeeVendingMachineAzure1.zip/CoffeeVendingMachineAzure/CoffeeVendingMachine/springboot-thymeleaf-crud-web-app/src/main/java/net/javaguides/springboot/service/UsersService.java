package net.javaguides.springboot.service;

import net.javaguides.springboot.model.Users;

public interface UsersService {

    Users registerUser(Users user);

    Users loginUser(String employeeId, String password);

}
