package net.javaguides.springboot.controller;

import net.javaguides.springboot.model.Machine;
import net.javaguides.springboot.model.Notification;
import net.javaguides.springboot.model.Admin;
import net.javaguides.springboot.service.AdminService;
import net.javaguides.springboot.service.MachineService;
import net.javaguides.springboot.service.NotificationService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.util.*;

@RestController
@RequestMapping("/api/notifications")
@CrossOrigin(origins = "*")
public class NotificationController {

    @Autowired
    private NotificationService notificationService;

    @Autowired
    private AdminService adminService;

    @Autowired
    private MachineService machineService;

    @GetMapping("/recent")
    public List<Notification> getRecentNotifications() {
        return notificationService.getRecentNotifications();
    }

    @GetMapping("/admin")
    public ResponseEntity<?> getNotificationsForAdmin(@RequestHeader("employeeId") String employeeId) {
        Optional<Admin> adminOpt = adminService.findByEmployeeId(employeeId);
        if (!adminOpt.isPresent()) {
            return ResponseEntity.status(401).body("Admin not found");
        }

        String machineId = adminOpt.get().getMachineId();
        List<Notification> notifications = notificationService.getNotificationsByMachineId(machineId);
        return ResponseEntity.ok(notifications);
    }

    // Alert endpoint with debug logs
    @GetMapping("/alerts")
    public ResponseEntity<?> getMachineAlerts(@RequestParam String location) {
        System.out.println("🔍 Checking alerts for location: " + location);

        List<Machine> machines = machineService.getMachinesByLocation(location);
        List<String> alerts = new ArrayList<>();

        for (Machine machine : machines) {
            System.out.println("➡️ Machine: " + machine.getMachineId() +
                    " | Temp: " + machine.getTemperature() +
                    " | Water: " + machine.getWaterLevel() +
                    " | Coffee: " + machine.getCoffeeLevel() +
                    " | Milk: " + machine.getMilkLevel() +
                    " | Sugar: " + machine.getSugarLevel());

            boolean lowIngredient = machine.getWaterLevel() < 30 ||
                    machine.getMilkLevel() < 30 ||
                    machine.getSugarLevel() < 30 ||
                    machine.getCoffeeLevel() < 30;

            boolean tempOutOfRange = machine.getTemperature() < 323 || machine.getTemperature() > 373;

            if (lowIngredient || tempOutOfRange) {
                alerts.add(machine.getMachineId());
                System.out.println("⚠️ Alert triggered for machine: " + machine.getMachineId());
            }
        }

        return ResponseEntity.ok(alerts);
    }
}
