package net.javaguides.springboot.service;

import net.javaguides.springboot.model.Notification;
import java.util.List;

public interface NotificationService {
    void createNotification(String message, String machineId);
    List<Notification> getRecentNotifications();
    List<Notification> getNotificationsByMachineId(String machineId);
}
