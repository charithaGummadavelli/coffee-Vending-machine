package net.javaguides.springboot.repository;
import java.util.*;
import net.javaguides.springboot.model.Technician;
import org.springframework.data.jpa.repository.JpaRepository;

public interface TechnicianRepository extends JpaRepository<Technician, Long> {
    Technician findByEmployeeId(String employeeId);
    List<Technician> findByMachineId(String machineId);

}
