// File: AdminController.java
package net.javaguides.springboot.controller;

import net.javaguides.springboot.model.Admin;
import net.javaguides.springboot.service.AdminService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.util.Optional;

@RestController
@RequestMapping("/api/admin")
@CrossOrigin(origins = "*")
public class AdminController {

    @Autowired
    private AdminService adminService;

    @GetMapping("/location/{location}")
    public ResponseEntity<?> checkLocationAccess(@PathVariable String location, @RequestHeader("employeeId") String employeeId) {
        if (employeeId.trim().isEmpty()) {
            return ResponseEntity.badRequest().body("Employee ID header is missing");
        }

        Optional<Admin> adminOpt = adminService.findByEmployeeId(employeeId);
        if (!adminOpt.isPresent()) {
            return ResponseEntity.status(HttpStatus.UNAUTHORIZED).body("Admin not found.");
        }

        Admin admin = adminOpt.get();
        if (!admin.getLocation().equalsIgnoreCase(location)) {
            return ResponseEntity.status(HttpStatus.FORBIDDEN)
                    .body("Access denied: You are only authorized for location " + admin.getLocation());
        }

        return ResponseEntity.ok().body("Access granted to " + location);
    }
}
