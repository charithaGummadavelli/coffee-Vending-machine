document.addEventListener("DOMContentLoaded", () => {
    updateDateTime();
    setInterval(updateDateTime, 1000);

    fetch("/api/users/me")
        .then(res => {
            if (!res.ok) throw new Error("Unauthorized");
            return res.json();
        })
        .then(user => {
            const empId = user.employeeId;

            document.getElementById("profileName").textContent = empId || "Admin";
            document.getElementById("empId").textContent = empId;

            // Load notifications
            loadNotifications(empId);

            // Location access
            document.querySelectorAll(".location").forEach(loc => {
                const locName = loc.dataset.location;

                loc.addEventListener("click", function (e) {
                    e.preventDefault();

                    fetch(`/api/admin/location/${locName}`, {
                        headers: {
                            "employeeId": empId
                        }
                    })
                    .then(res => {
                        if (!res.ok) {
                            return res.text().then(msg => { throw new Error(msg); });
                        }

                        window.location.href = `/admin-machine?location=${locName}`;
                    })
                    .catch(err => {
                        alert(err.message || "Access denied: You are not authorized for this location.");
                    });
                });
            });
        })
        .catch(() => {
            alert("Session expired. Please log in again.");
            window.location.href = "/login";
        });
});

function updateDateTime() {
    const now = new Date();
    const formatted = now.toLocaleString('en-IN', {
        weekday: 'short',
        year: 'numeric',
        month: 'short',
        day: 'numeric',
        hour: '2-digit',
        minute: '2-digit',
        second: '2-digit',
        hour12: true
    });
    document.getElementById('current-datetime').textContent = formatted;
}

function logout() {
    fetch("/api/users/logout", { method: "POST" })
        .finally(() => {
            localStorage.clear();
            sessionStorage.clear();
            window.location.href = "/index";
        });
}

function loadNotifications(empId) {
    fetch("/api/notifications/admin", {
        headers: {
            "employeeId": empId
        }
    })
    .then(res => res.json())
    .then(notifications => {
        const list = document.getElementById("notificationList");
        list.innerHTML = "";

        if (notifications.length === 0) {
            list.innerHTML = "<li>No notifications</li>";
            return;
        }

        notifications.forEach(n => {
            const li = document.createElement("li");
            li.textContent = `${new Date(n.timestamp).toLocaleString()} - ${n.message}`;
            list.appendChild(li);
        });
    })
    .catch(err => {
        console.error("Failed to load notifications:", err);
    });
}
