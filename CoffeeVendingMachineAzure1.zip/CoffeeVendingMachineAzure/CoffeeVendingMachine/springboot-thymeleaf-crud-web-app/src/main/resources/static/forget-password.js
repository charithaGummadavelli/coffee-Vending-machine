document.getElementById('resetPasswordBtn').addEventListener('click', function () {
  const employeeId = document.getElementById('resetEmployeeId').value.trim();
  const newPassword = document.getElementById('newPassword').value.trim();
  const confirmPassword = document.getElementById('confirmPassword').value.trim();

  if (!/^\d{7}$/.test(employeeId)) {
    showMessage('Employee ID must be exactly 7 digits and numeric', true);
    return;
  }

  if (!/^(?=.*[A-Za-z])(?=.*\d)(?=.*[@$!%*#?&]).{8,}$/.test(newPassword)) {
    showMessage('Password must be at least 8 characters and include letters, numbers, and special characters', true);
    return;
  }

  if (newPassword !== confirmPassword) {
    showMessage('First entered password is different from second. Please check twice.', true);
    return;
  }

  fetch('http://localhost:8080/api/users/reset-password', {
    method: 'POST',
    headers: { 'Content-Type': 'application/json' },
    body: JSON.stringify({ employeeId, newPassword })
  })
    .then(response => {
      if (!response.ok) throw new Error('Reset failed');
      return response.text();
    })
    .then(() => {
      showMessage('Password updated successfully!');
      setTimeout(() => {
        window.location.href = '/index';
      }, 2000);
    })
    .catch(error => showMessage(error.message, true));
});

function showMessage(msg, isError = false) {
  const el = document.getElementById('message');
  el.textContent = msg;
  el.style.color = isError ? 'red' : 'light-blue';
}
